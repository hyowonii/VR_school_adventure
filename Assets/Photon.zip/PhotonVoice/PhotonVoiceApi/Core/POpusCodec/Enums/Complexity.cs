﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace POpusCodec.Enums
{
    public enum Complexity : int
    {
        Complexity0 = 0,
        Complexity1 = 1,
        Complexity2 = 2,
        Complexity3 = 3,
        Complexity4 = 4,
        Complexity5 = 5,
        Complexity6 = 6,
        Complexity7 = 7,
        Complexity8 = 8,
        Complexity9 = 9,
        Complexity10 = 10
    }
}
